// BlogForm.jsx
import React, { useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css'; // Import the styles for the Quill editor

const BlogForm = ({ onSubmit }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};

    // Validate title
    if (!title.trim()) {
      newErrors.title = 'Title is required';
    }

    // Validate content
    if (!content.trim()) {
      newErrors.content = 'Content is required';
    }

    setErrors(newErrors);

    // Return true if there are no errors
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate the form before submitting
    if (validateForm()) {
      // Create a new blog object
      const newBlog = {
        title,
        content,
      };

      // Pass the new blog to the parent component
      onSubmit(newBlog);

      // Clear the form fields
      setTitle('');
      setContent('');
      setErrors({});
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="title">Title:</label>
      <input
        type="text"
        id="title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      {errors.title && <p className="error">{errors.title}</p>}
      <label htmlFor="content">Content:</label>
      <ReactQuill
        id="content"
        value={content}
        onChange={(value) => setContent(value)}
        modules={{
          toolbar: [
            [{ header: [1, 2, false] }],
            ['bold', 'italic', 'underline', 'strike', 'blockquote'],
            [{ list: 'ordered' }, { list: 'bullet' }],
            ['link', 'image'],
            ['clean'],
          ],
        }}
      />
      {errors.content && <p className="error">{errors.content}</p>}
      <button type="submit">Submit</button>
    </form>
  );
};

export default BlogForm;
