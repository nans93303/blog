// Navigation.jsx
import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faBars } from '@fortawesome/free-solid-svg-icons';
import './Navigation.css'; 

const Navigation = () => {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div>
      {/* Top Navigation */}
      <nav className={`top-nav ${isMobileMenuOpen ? 'mobile-menu-open' : ''}`}>
        <div className="top-nav-left">
          <a href="#">Subscribe</a>
        </div>
        <div className="top-nav-center">
          <h1>Large</h1>
        </div>
        <div className="top-nav-right">
          <div className="search-icon">
            <FontAwesomeIcon icon={faSearch} />
          </div>
          <button className="signup-button">Sign Up</button>
          
        </div>
      </nav>

       {/* Horizontal Line */}
       <hr className="horizontal-line" />

        {/* Hamburger Icon for Mobile */}
        <div className="hamburger-icon" onClick={toggleMobileMenu}>
            <FontAwesomeIcon icon={faBars} />
          </div>


     

      {/* Navigation Items (Mobile) */}
      <nav className={`nav-items ${isMobileMenuOpen ? 'mobile-menu-open' : ''}`}>
        <ul>
          <li><a href="#">World</a></li>
          <li><a href="#">U.S.</a></li>
          <li><a href="#">Technology</a></li>
          <li><a href="#">Design</a></li>
          <li><a href="#">Culture</a></li>
          <li><a href="#">Business</a></li>
          <li><a href="#">Politics</a></li>
          <li><a href="#">Opinion</a></li>
          <li><a href="#">Science</a></li>
          <li><a href="#">Health</a></li>
          <li><a href="#">Style</a></li>
          <li><a href="#">Travel</a></li>
        </ul>
      </nav>
    </div>
  );
};

export default Navigation;
