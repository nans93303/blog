// App.jsx
import React, { useState } from 'react';
import Navigation from './Navigation';
import NewHero from './NewHero';
import './App.css';
import BlogContainer from './BlogContainer';
import BlogForm from './BlogForm';

function App() {
  const [blogs, setBlogs] = useState([]);

  const handleBlogSubmit = (newBlog) => {
    // Update the blogs array with the new blog
    setBlogs([...blogs, newBlog]);
  };

  return (
    <div>
      <Navigation />
      <NewHero />
      <BlogContainer blogs={blogs} />
      <BlogForm onSubmit={handleBlogSubmit} />
    </div>
  );
}

export default App;
