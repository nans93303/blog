// HeroComponent.jsx
import React from 'react';
import './HeroBlock.css'; // You can create a separate CSS file for styling

const HeroBlock = ({ heading, description, imageUrl }) => {
  return (
    <div className="hero-container">
      <div className="hero-content">
        <h1>{heading}</h1>
        <p>{description}</p>
      </div>
      <div className="hero-image">
        <img src={imageUrl} alt="Hero" />
      </div>
    </div>
  );
};

export default HeroBlock;
