// BlogContainer.jsx
import React from 'react';

const BlogContainer = ({ blogs }) => {
  return (
    <div className="blog-container">
      {/* Display submitted blogs */}
      {blogs.map((blog, index) => (
        <div key={index} className="blog-item">
          <h3>{blog.title}</h3>
          <p>
            <strong>{blog.date} by {blog.userName}</strong> {/* Display user name */}
          </p>
          
          <div dangerouslySetInnerHTML={{ __html: blog.content }} />
        </div>
      ))}
    </div>
  );
};

export default BlogContainer;
