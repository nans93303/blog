// App.jsx
import React, { useState } from 'react';
import Navigation from './Navigation';
import NewHero from './NewHero';
import BlogContainer from './BlogContainer';
import BlogForm from './BlogForm'; // Corrected import

import './App.css';

function App() {
  const [blogs, setBlogs] = useState([]);

  const handleBlogSubmit = (newBlog) => {
    // Update the blogs array with the new blog
    setBlogs([...blogs, newBlog]);
  };

  return (
    <div>
      <Navigation />
      <NewHero />
      <div className="app-container"> {/* Wrap the components in a container */}
        <BlogContainer blogs={blogs} />
        <BlogForm onSubmit={handleBlogSubmit} />
      </div>
    </div>
  );
}

export default App;
