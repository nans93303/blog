// BlogForm.jsx
import React, { useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

const BlogForm = ({ onSubmit }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [userName, setUserName] = useState(''); // Added state for user name
  const [errors, setErrors] = useState({});

  const getCurrentDate = () => {
    const currentDate = new Date();
    const day = currentDate.getDate();
    const month = currentDate.toLocaleString('default', { month: 'long' });
    const year = currentDate.getFullYear();
    return `${day} ${month} ${year}`;
  };

  const validateForm = () => {
    const newErrors = {};

    if (!title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!content.trim()) {
      newErrors.content = 'Content is required';
    }

    if (!userName.trim()) { // Validate user name
      newErrors.userName = 'User name is required';
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validateForm()) {
      const newBlog = {
        title,
        content,
        userName,
        date: getCurrentDate(), // Adding the current date to the blog object
      };

      onSubmit(newBlog);

      setTitle('');
      setContent('');
      setUserName('');
      setErrors({});
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="title">Title:</label>
      <input
        type="text"
        id="title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      {errors.title && <p className="error">{errors.title}</p>}
      <label htmlFor="content">Content:</label>
      <ReactQuill
        id="content"
        value={content}
        onChange={(value) => setContent(value)}
        modules={{
          toolbar: [
            [{ header: [1, 2, false] }],
            ['bold', 'italic', 'underline', 'strike', 'blockquote'],
            [{ list: 'ordered' }, { list: 'bullet' }],
            ['link', 'image'],
            ['clean'],
          ],
        }}
      />
      {errors.content && <p className="error">{errors.content}</p>}
      <label htmlFor="userName">Your Name:</label>
      <input
        type="text"
        id="userName"
        value={userName}
        onChange={(e) => setUserName(e.target.value)}
      />
      {errors.userName && <p className="error">{errors.userName}</p>}
      <button type="submit">Submit</button>
    </form>
  );
};

export default BlogForm;
